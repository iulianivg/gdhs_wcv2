# Dex frontend


Instructions for running code:

- use yarn instead of npm
- node v16.18.0
- use "yarn" to install node_modules

Once node_modules installed, copy /@pancakeswap-libs folder and replace the one inside node_modules

