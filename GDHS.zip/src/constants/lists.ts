export const DEFAULT_TOKEN_LIST_URL = 'pancakeswap'

export const DEFAULT_LIST_OF_LISTS: string[] = [DEFAULT_TOKEN_LIST_URL]
